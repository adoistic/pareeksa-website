---
name: pareeksa-brand
description: Pareeksa Technologies brand and visual-identity system. Use whenever you create a deliverable for Pareeksa — presentations, documents, websites, landing pages, React/HTML, brochures, PDFs, decks, one-pagers, emails, or social assets. Supplies the logo, colour palette, typography, components, and tone of voice. Layer it on top of the relevant file-creation skill (pptx, docx, frontend-design, pdf, xlsx); it styles the output, it does not replace the generator.
---

# Pareeksa — Brand & Identity (public)

This skill makes any deliverable look and read like **Pareeksa Technologies**. It is a brand
*layer*: pair it with whatever creation skill fits the format and apply the identity below.

> **Press & brand enquiries:** corp@pareeksa.com · Full guidelines: https://pareeksa.com/brand.html

---

## 0 · What Pareeksa is

Pareeksa Technologies builds examination technology — OMR scanning, on-screen marking and
online exams — and the work around it (OCR/ICR, document management, secure printing, custom
apps, AI, security testing, translation). The name is **परीक्षा** (Sanskrit, "examination";
*pari + īkṣ*, "to see thoroughly"). Memorable thing: **precise and trustworthy.**

- **Tagline:** The exam, examined.
- **Tone:** serious infrastructure for high-stakes work — never hype SaaS.

## 1 · The logo

A **fountain-pen nib** — the instrument of the examiner's mark. Flat, head-on, bilaterally
symmetrical; the breather hole and slit are true negative space. **Lead with the symbol;** a
wordmark and lockups exist for when the name is needed.

**Bundled assets (`assets/`):**
- `pareeksa-mark-recolorable.svg` — single-path nib, `fill="currentColor"`. Recolour via CSS.
- `pareeksa-appicon.svg` — blue tile + white nib. The **only** place the tile is used (favicon/app icon).
- `pareeksa-lockup-horizontal.svg` — primary lockup (nib + wordmark, vector).
- `pareeksa-lockup-stacked.svg` — stacked lockup (nib above wordmark).
- `Geist-variable.woff2`, `GeistMono-variable.woff2`, `OFL.txt` — the typefaces + licence.

**Wordmark:** "Pareeksa" in **Geist Semibold (600), tracking −0.02em**. Fixed case — never all-caps, never restyled.

### Which asset, where
| Context | Use |
|---|---|
| Favicon / app icon / avatar tile | app-icon (blue tile + white nib) |
| In-product top bar / tight spaces | symbol only (mark) |
| Marketing header, doc letterhead, deck cover, email | horizontal lockup (primary) |
| Square / social / cover | stacked lockup, or large symbol + tagline |
| On dark or on brand blue | reversed (all-white) variant |
| Single-colour print | all-ink variant |
| Beside a partner/university logo | horizontal lockup, hairline divider; the partner leads |

### Clear space, sizing, misuse
- **Clear space** = the nib's breather-hole diameter on all sides.
- **Minimum size:** symbol 24px screen / 16px favicon; horizontal lockup ≥ 120px wide.
- **Never:** stretch/distort · recolour off-palette · rotate/tilt · add gloss/bevel/gradient/
  shadow/3D · change the wordmark font · reorder the lockup (wordmark never leads) · place on a
  busy or low-contrast ground.

## 2 · Colour

Restrained by design. Colour means status, action, or a mark — never decoration.

```
--brand    #1D4ED8   Institutional blue — accent, primary action, app-icon tile, links
--ink      #16181D   Near-black — the mark, headings, body text
--bg       #F7F8FA   Near-white surface (not pure white)
--surface  #FFFFFF   Cards / panels
--muted    #626875   Secondary text, captions
--hairline #E6E8EC   Borders, dividers
--mark-red #E5484D   RESERVED for marker annotations only — never UI or decoration
```
Semantic: success `#16A34A` · warning `#D97706` · error `#DC2626` · info = `--brand`.
**Dark mode** (redesigned, not inverted): bg `#0E0F13`, surface `#16181D`, ink `#E6E8EC`,
muted `#9AA1AE`, hairline `#262A33`; brand reads brighter (`~#7CA0FF` for links).
**Discipline:** one accent (brand blue). No purple/rainbow gradients, no decorative colour.

## 3 · Typography

- **Geist Sans** — UI, headings, body, the wordmark. Hierarchy by weight + size, not by mixing families.
- **Geist Mono** — **every** numeral, score, total, code, ID, timestamp (`tabular-nums`). The precision signature.
- **Never** Inter, Roboto, Arial, or Space Grotesk.
- **Scale (rem):** caption .75 · small .875 · body 1.0 · lead 1.125 · h3 1.25 · h2 1.5 · h1 2.0 · display 2.5.

Web embed (copy the bundled woff2 next to the output):
```css
@font-face{font-family:"Geist";src:url("Geist-variable.woff2") format("woff2");font-weight:400 700;font-display:swap}
@font-face{font-family:"Geist Mono";src:url("GeistMono-variable.woff2") format("woff2");font-weight:400 500;font-display:swap}
```

## 4 · Components & layout — "Quiet Precision"

Calm, exact, modern best-software craft (the restraint of Linear/Notion), tuned for seriousness.
- **Surfaces:** near-white bg, white cards, **hairline borders**, at most one subtle elevation. No drop shadows by default, no gradients, no texture.
- **Radius:** 4px inputs/chips · 8px cards · 12px modals · full for avatars/dots.
- **Spacing:** 4px base (2/4/8/12/16/24/32/48/64). Generous whitespace.
- **Buttons:** primary = brand fill, white label, 8px radius; secondary = hairline outline, ink label; ghost = text only. No gradient buttons.
- **Alignment is the craft** — everything on the 4px grid.
- **Motion (if any):** minimal, functional, 150–250ms ease-out. No bounce.

**Anti-slop (never produce):** purple/blue gradients · 3-column icon-in-circle feature grids ·
centered-everything · bubbly uniform radii · decorative blobs/waves · emoji as design elements ·
stock-photo heroes · "Welcome to / Unlock the power of" copy · system-ui as a display font.

## 5 · Voice & tone

Precise, calm, accountable. Utility language, not marketing mood — say what a thing is, its
status, and the next action. Short sentences, concrete nouns, active voice, exact numbers in mono.
Reassure under stress; never accusatory or alarmist. Avoid "seamless, powerful, revolutionary,
robust, comprehensive." Lead with the point; close with what the reader can now do.

## 6 · Checklist before delivering

- [ ] Correct logo asset for the context; clear space + minimum size respected.
- [ ] Geist + Geist Mono only; every number in mono.
- [ ] Palette limited to the tokens above; one accent (brand blue); marking-red unused.
- [ ] Quiet-Precision surfaces: hairlines, restrained radius, no gradients/shadows/slop.
- [ ] Voice precise and calm — no hype.
- [ ] Light + dark handled (web); numerics in mono (sheets); backgrounds print (PDF).
