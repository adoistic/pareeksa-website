PAREEKSA TECHNOLOGIES — LOGO & BRAND ASSETS
The exam, examined.

Files
  pareeksa-mark-*           The fountain-pen nib (the mark). ink / white / blue / recolorable.
  pareeksa-mark-on-*.jpg    The mark on a solid background (no transparency in JPG).
  pareeksa-appicon.*        App-icon tile (blue + white nib). Use only as an app/favicon tile.
  pareeksa-lockup-horizontal-*   Primary lockup: mark + "Pareeksa" wordmark.
  pareeksa-lockup-stacked-*      Stacked lockup: mark above wordmark.
  Geist / GeistMono (woff2) The brand typefaces (SIL Open Font License — see OFL.txt).

Colours
  Brand blue #1D4ED8   Ink #16181D   Surface #FFFFFF   Near-white #F7F8FA
  Muted #6B7280   Hairline #E6E8EC   Marking red #E5484D (reserved for marker annotations only)

Quick rules
  - Lead with the symbol. Wordmark in Geist Semibold, tracking -0.02em, fixed case "Pareeksa".
  - Clear space = the nib's breather-hole diameter on all sides. Min symbol size 24px (16px favicon).
  - Reversed (white) on dark or on brand blue. All-ink for single-colour print.
  - Never stretch, recolour off-palette, rotate, add effects, or reorder the lockup.

Full guidelines: https://pareeksa.com/brand.html
Press & brand enquiries: corp@pareeksa.com
